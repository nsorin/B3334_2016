/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metier.modele;

import java.util.Date;
import java.util.List;
import javax.persistence.ManyToMany;

/**
 *
 * @author ovicente
 */
public class EvenementAvecEquipe extends Evenement {
 
    @ManyToMany
    private List<Adherent> equipeA;
    @ManyToMany
    private List<Adherent> equipeB;
    
    public EvenementAvecEquipe(Date date, Activite activite, Lieu lieu, List<Demande> demandes) {
        super(date, activite, lieu, demandes);
        boolean a = true;
        for(Demande d : demandes) {
            if(a) {
                equipeA.add(d.getAdherent());
                a = false;
            } else {
                equipeB.add(d.getAdherent());
                a = true;
            }
        }
    }

    public List<Adherent> getEquipeA() {
        return equipeA;
    }

    public void setEquipeA(List<Adherent> equipeA) {
        this.equipeA = equipeA;
    }

    public List<Adherent> getEquipeB() {
        return equipeB;
    }

    public void setEquipeB(List<Adherent> equipeB) {
        this.equipeB = equipeB;
    }

    @Override
    public String toString() {
        return super.toString() + "EvenementAvecEquipe{" + "equipeA=" + equipeA + ", equipeB=" + equipeB + '}';
    }
    
    
    
}
