/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import dao.ActiviteDao;
import dao.AdherentDao;
import dao.JpaUtil;
import dao.LieuDao;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import metier.modele.Activite;
import metier.modele.Adherent;
import metier.modele.Lieu;

/**
 *
 * @author ovicente
 */
public class Main {
    
    public static void main(String[] args) {
        System.out.println("Bonjour. Que voulez-vous faire ?");
        JpaUtil.creerEntityManager();
        int input = 0;
        Scanner sc = new Scanner(System.in);
        JpaUtil.ouvrirTransaction();
        while(input != 4) {
            System.out.println("1-Gérer adhérents/ 2-Gérer Activités / 3-Gérer Lieux /4-Exit");
            input = sc.nextInt();
            switch(input) {
                case 1:
                    gererAdherents(sc);
                    break;
                case 2:
                    gererActivite(sc);
                    break;
                case 3:
                    gererLieux(sc);
                    break;
                case 4:
                    JpaUtil.validerTransaction();
                    break;
                default:
                    System.out.println("Commande non connue réessayez");
            }
        }
        sc.close();
        JpaUtil.fermerEntityManager();
      
    }
    
    public static void gererAdherents(Scanner sc){
        int input = 0;
        AdherentDao ad = new AdherentDao();
        while(input!=3){
            System.out.println("1-Créer adhérents/ 2-Afficher la liste des adhérents /3-Retour");
            input = sc.nextInt();
            switch(input) {
                case 1:
                    creerAdherent(ad);
                    break;
                case 2:
                    afficherAdherents(ad);
                    break;
                case 3:
                    JpaUtil.validerTransaction();
                    JpaUtil.ouvrirTransaction();
                    break;
                default:
                    System.out.println("Commande non connue réessayez");
            }
        }
    }
    
    public static void gererActivite(Scanner sc){
        int input = 0;
        ActiviteDao ad = new ActiviteDao();
        while(input!=3){
            System.out.println("1-Créer Activité/ 2-Afficher la liste des activités /3-Retour");
            input = sc.nextInt();
            switch(input) {
                case 1:
                    creerActivite(ad);
                    break;
                case 2:
                    afficherActivites(ad);
                    break;
                case 3:
                    JpaUtil.validerTransaction();
                    JpaUtil.ouvrirTransaction();
                    break;
                default:
                    System.out.println("Commande non connue réessayez");
            }
        }
    }
    
    public static void gererLieux(Scanner sc){
        int input = 0;
        LieuDao ld = new LieuDao();
        while(input!=3){
            System.out.println("1-Créer Lieu/ 2-Afficher la liste des lieux /3-Retour");
            input = sc.nextInt();
            switch(input) {
                case 1:
                    creerLieu(ld);
                    break;
                case 2:
                    afficherLieux(ld);
                    break;
                case 3:
                    JpaUtil.validerTransaction();
                    JpaUtil.ouvrirTransaction();
                    break;
                default:
                    System.out.println("Commande non connue réessayez");
            }
        }
    }
    
    public static void creerAdherent(AdherentDao ad) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Entrez nom");
        String lastname = sc.nextLine();
        System.out.println("Entrez prénom");
        String firstname = sc.nextLine();
        System.out.println("Entrez adresse");
        String address = sc.nextLine();
        System.out.println("Entrez mail");
        String mail = sc.nextLine();
        try {
            if(!ad.create(new Adherent(lastname, firstname, address, mail))){
                System.out.println("L'adresse de l'adhérent est non conforme!");
            }
        } catch (Throwable ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void afficherAdherents(AdherentDao ad) {
        System.out.println("Liste des adhérents :");
        try {
            List<Adherent> list = ad.findAll();
            for(Adherent a : list) {
                System.out.println(a);
            }
        } catch (Throwable ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void creerActivite(ActiviteDao ad) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Entrez dénomination :");
        String denomination = sc.nextLine();
        System.out.println("y a-t-il des équipes (true/false) :");
        boolean equipe = sc.nextBoolean();
        System.out.println("Entrez le nombre des participants :");
        Integer nbParticipants = sc.nextInt();
        try {
            ad.create(new Activite(denomination, equipe, nbParticipants));
        } catch (Throwable ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void afficherActivites(ActiviteDao ad) {
        System.out.println("Liste des adhérents :");
        try {
            List<Activite> list = ad.findAll();
            for(Activite a : list) {
                System.out.println(a);
            }
        } catch (Throwable ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void creerLieu(LieuDao ld) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Entrez dénomination :");
        String denomination = sc.nextLine();
        System.out.println("Entrez description :");
        String description = sc.nextLine();
        System.out.println("Entrez adresse :");
        String address = sc.nextLine();
        try {
            if(!ld.create(new Lieu(denomination, description, address))){
                System.out.println("L'adresse de l'adhérent est non conforme!");
            }
        } catch (Throwable ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void afficherLieux(LieuDao ld) {
        System.out.println("Liste des adhérents :");
        try {
            List<Lieu> list = ld.findAll();
            for(Lieu l : list) {
                System.out.println(l);
            }
        } catch (Throwable ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
